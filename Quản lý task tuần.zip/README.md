
  # Quản lý task tuần

  This is a code bundle for Quản lý task tuần. The original project is available at https://www.figma.com/design/cuxkVNIXpvupmTWHggk0cP/Qu%E1%BA%A3n-l%C3%BD-task-tu%E1%BA%A7n.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  